# Global variable

HawkeyeCommunityCollege = "NET202 Programming for NETAd"

def Python_Programming():
    #access the varible 'HawkeyeCommunityCollege' inside the function
    print(f"The best place to learn to code is at {HawkeyeCommunityCollege}!")

#Call the function
Python_Programming()

#Access the variable 'HawkeyeCommunityCollege' from outside the fucntion
print(HawkeyeCommunityCollege)
