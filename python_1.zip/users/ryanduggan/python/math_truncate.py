# Truncate a float in python with math.trun()
import math

float1 = 123.456
float2 = 2434.545

print(math.trunc(float1))
print(math.trunc(float2))

