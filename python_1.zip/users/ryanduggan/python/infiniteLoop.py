# If stuck in an infinite loop, press Ctrl + C or select Shell > Restart Shell
while True:
    print('Hello, world!')
