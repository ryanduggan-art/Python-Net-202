#Class Example

class Employee:
    #defin an attribute
    employee_id = 0

employee1 = Employee()
employee2 = Employee()

#Access attributes using employee1
employee1.employeeID = 1001
print(f'Employee ID: {employee1.employeeID}')

#Access attributes using employee2
employee2.employeeID = 1002
print(f'Employee ID: {employee2.employeeID}')

