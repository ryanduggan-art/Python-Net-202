#in class example of error handling
x = 'five'
y = x + 5
