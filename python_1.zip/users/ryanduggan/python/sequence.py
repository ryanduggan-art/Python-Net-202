#Sequence Data Types

name = 'Professor Griffiths'
name [0]
name [-2]
name [0:4]
'Prof' in name
'G' in name
'k' not in name
for s in name:
    print('***'+s+'***')
