# Unique ID

x = 42
y =x
z = 42

print(id(x))
print(id(y))
print(id(z))


