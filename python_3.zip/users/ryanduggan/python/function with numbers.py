# Function that adds numbers
def add_numbers (num1, num2):
    sum = num1 + num2
    return sum

#Calling function with two values
result = add_numbers (9, 6)

print ('sum: ', result)


