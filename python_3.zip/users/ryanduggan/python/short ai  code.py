i=input();print(['The','name','entered','is',i]);print(len(i)+7)

