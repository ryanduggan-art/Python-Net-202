
import random
random_number = random.randint(1,6) #Sets random_number to a random integer between 1-6

def get_random_dice_roll():
    #Returns a random integer from 1 to 6
    return random_number

print(get_random_dice_roll())
print(get_random_dice_roll())
print(get_random_dice_roll())
print(get_random_dice_roll())
