#Pathlib

import pathlib
p = pathlib.Path(__file__)
print(p)
