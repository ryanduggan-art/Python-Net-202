# Week 2 Exit List Manipulation Assignment

# Activies Over the Weekend

Friday = ['Vet','Homework','Study','Work']
Saturday = ['Work','Clean','Groceries','Cyberpunk']
Sunday = ['Church','Walk Dog','BTO']
Monday = ['Sleep','Fix HVAC','Laundry','Walmart']

print('Friday List:', Friday)
print('Bag Elements:', len(Saturday))

