# OS.MAKEDIR()
# Import OS LIB
import os
#Create DIR
os.makedirs("c:/NET202/HCC")
