# Flowchart vampire example
name = 'Carol'
age = 3000
if name == 'Alice':
    print('Hi Alice.')
elif age < 12:
    print('You are not Alice, kiddo.')
else:
    print('You are neither Alice nor a little kid.')
