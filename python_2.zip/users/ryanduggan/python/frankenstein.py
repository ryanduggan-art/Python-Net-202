string = f"The name entered is {input('Please enter your name:')}"
print(string, string.split(), f"Total Length: {len(string[20:]) + 7}", sep = '\n')
