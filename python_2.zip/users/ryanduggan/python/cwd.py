#Current Working Directory
import os

# Get the CWD
cwd = os.getcwd()

# print put to console
print(cwd)


