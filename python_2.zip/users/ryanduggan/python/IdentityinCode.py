# This is my first and last name in code
firstName = 'Ryan'
lastName = ' Duggan'
print(firstName + lastName)
