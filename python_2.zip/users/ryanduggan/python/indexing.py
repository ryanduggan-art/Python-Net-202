# Find the index of an element

list = ['Ryan', 'Mindy', 'Michael', 'Kylen', 'Kael']

# Will print the index of names in list
print(list.index('Kylen'))
print(list.index('Michael'))
print(list.index('Mindy'))
print(list.index('Kael'))
print(list.index('Ryan'))
