# Writing list

Kitchen = ["bacon", "toaster", "cheese"]

print(Kitchen)
