# Global Variable
integer_additive = 7
print('Please enter your name:')
name_input = input()
print_output = print('The name entered is ' + name_input)
create_a_list = ['The', 'name', 'entered', 'is'] + [name_input]
get_length_of_list = (len(name_input) + integer_additive)
print(create_a_list)
print(get_length_of_list)
print("This is a test change for Git practice")
