# A comment is so you can read the program later.
# Anything after the # is ignored in Python.
print("Hello World")
print("Name")
print("I like coding Python")
print("NET202 is fun")
print("Hawkeye Community College")
# You can also use a comment to "disable or comment out codeL:
#print("Professor Griffths")
print("Week1Exit")
